package com.example.spherebox;

import android.content.Context;
import android.view.View;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.graphics.PointF;

public class SphereView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private double rotX = -0.30, rotY = 0.42;
    private static final double R = 1.0;
    private static final int PURPLE = Color.rgb(190, 80, 255);
    private static final int GREEN = Color.rgb(50, 230, 120);
    private static final int RED = Color.rgb(255, 65, 75);
    private static final int YELLOW = Color.rgb(255, 220, 30);

    public SphereView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

    public void rotate(double dxDegrees, double dyDegrees) {
        rotX += Math.toRadians(dxDegrees);
        rotY += Math.toRadians(dyDegrees);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.BLACK);
        float scale = Math.min(getWidth(), getHeight()) * 0.34f;
        float cx = getWidth()/2f, cy = getHeight()/2f - 8;
        // White solid sphere.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(cx, cy, scale * 0.70f, paint);

        // Three great circles on the sphere. Draw only the visible hemisphere.
        drawGreatCircle(canvas, cx, cy, scale * 0.70f, 0, PURPLE);
        drawGreatCircle(canvas, cx, cy, scale * 0.70f, 1, GREEN);
        drawGreatCircle(canvas, cx, cy, scale * 0.70f, 2, RED);

        // Wireframe cube surrounding the sphere, projected in the same orientation.
        double h = 1.16;
        double[][] v = {
            {-h,-h,-h},{h,-h,-h},{h,h,-h},{-h,h,-h},
            {-h,-h,h},{h,-h,h},{h,h,h},{-h,h,h}
        };
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, getResources().getDisplayMetrics().density * 2f));
        paint.setColor(YELLOW);
        paint.setStrokeCap(Paint.Cap.ROUND);
        PointF[] projected = new PointF[8];
        for (int i=0;i<8;i++) projected[i] = project(v[i][0],v[i][1],v[i][2],cx,cy,scale);
        for (int[] e : edges) canvas.drawLine(projected[e[0]].x, projected[e[0]].y, projected[e[1]].x, projected[e[1]].y, paint);
    }

    private void drawGreatCircle(Canvas c, float cx, float cy, float radius, int plane, int color) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2.5f, getResources().getDisplayMetrics().density * 2.3f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(color);
        Path path = new Path();
        boolean started = false;
        // Each circle is sampled in 3D and rotated together with the scene.
        for (int i=0;i<=240;i++) {
            double t = 2*Math.PI*i/240.0;
            double x, y, z;
            if (plane == 0) { x=0; y=Math.cos(t); z=Math.sin(t); }
            else if (plane == 1) { x=Math.cos(t); y=0; z=Math.sin(t); }
            else { x=Math.cos(t); y=Math.sin(t); z=0; }
            double[] p = rotatePoint(x,y,z);
            // Hide the rear half so each colored circle lies on the visible surface.
            if (p[2] < -0.015) { started = false; continue; }
            PointF q = projectRotated(p[0],p[1],p[2],cx,cy,radius);
            if (!started) { path.moveTo(q.x,q.y); started=true; }
            else path.lineTo(q.x,q.y);
        }
        c.drawPath(path, paint);
    }

    private PointF project(double x,double y,double z,float cx,float cy,float scale) {
        double[] p=rotatePoint(x,y,z);
        return projectRotated(p[0],p[1],p[2],cx,cy,scale);
    }

    private PointF projectRotated(double x,double y,double z,float cx,float cy,float scale) {
        // Slight perspective makes the cube read as three-dimensional.
        double perspective = 3.8 / (3.8 - z * 0.12);
        return new PointF((float)(cx + x*scale*perspective), (float)(cy - y*scale*perspective));
    }

    private double[] rotatePoint(double x,double y,double z) {
        double cy=Math.cos(rotY), sy=Math.sin(rotY);
        double x1=x*cy+z*sy, z1=-x*sy+z*cy;
        double cx=Math.cos(rotX), sx=Math.sin(rotX);
        double y1=y*cx-z1*sx, z2=y*sx+z1*cx;
        return new double[]{x1,y1,z2};
    }
}
